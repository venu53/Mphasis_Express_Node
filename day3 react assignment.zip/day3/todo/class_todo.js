import React from "react";
import Todo from "./class_todo1";

class TodoList extends React.Component{
    constructor(props){
        super(props);

        this.state={
            todos:[], newtodo:"",
        };
    }


    handleInputChange=(e)=>{
        this.setState({newtodo:e.target.value});

    };

    addtodo=()=>{

        if(this.state.newtodo.trim()!==""){
            this.setState({
                todo:[...this.state.todos,this.state.newtodo],
                newtodo:"",
            });
        }
    };

    removetodo=(index)=>{
        const updatedtodos=[...this.state.todos];
        updatedtodos.splice(index,1);
        this.setState({todos:updatedtodos});
    };

    render() {
        return(
            <div>
                <h2>todolist</h2>

                <div>
                    <input type="text" value={this.state.newtodo} onChange={this.handleInputChange} placeholder="add here"/>
                    <button onClick={this.addtodo}>Add</button>
                </div>
                <Todo/>
            </div>

        )
    };


}
export default TodoList;