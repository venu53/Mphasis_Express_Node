import React from "react";

const Todo=({todo,onDelete})=>{

    return(
        <div>
            <p>{todo}</p>
            <button onClick={onDelete}>
                Delete
            </button>
        </div>
    );
}

export default Todo;