import React from "react";
import { useState } from "react";
import Products from './products';
function Product_main() {


    let [category, setCategory] = useState("");
    return (
        <>
            <div>
               

                <label >Choose a category:</label>

                <select name="category" onChange={(e)=>setCategory(e.target.value)} >
                     <option value="All Products">All Products</option>
                <option value="Electronics">Electronics</option>
                <option value="Clothing">Clothing</option>
               
                <option value="Food">Food</option>
            </select>

                {/* <input type ="text" value={category} onChange={(e) => setCategory (e.target.value)} /> */}
            </div>

            <Products category={category} />

        </>


    )
}


export default Product_main;