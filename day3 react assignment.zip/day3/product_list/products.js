import React from "react";
import { useState } from "react";

function Product(props) {


    const products = [
      { id: 1, name: 'Product A', category: 'Electronics' },
      { id: 2, name: 'Product B', category: 'Clothing' },
      { id: 3, name: 'Product C', category: 'Electronics' },
      { id: 4, name: 'Product D', category: 'Clothing' },
      { id: 5, name: 'Product E', category: 'Food' }
    ];
    
    
    let resultarray= products.filter( (item)=>item.category===props.category);
    console.log(resultarray);
    
      return (
        <>
       
        <h2>products and category is <p style={{"color":"red","marginRight":"50px"}}>"{props.category}"</p></h2>


       { (resultarray.length == 0 ?
       
        <div  style={{"border":"2px solid black","height":"200px","width":"500px","backgroundColor":"lightgreen","padding":"10px","display":"flex"}} >{products.map((item) =>(
       
        <div style={{"border":"2px solid black","height":"150px","width":"80px","backgroundColor":"lightskyblue","alignItems":"center","padding":"10px","margin":"5px"}}>
        <p>{item.id}</p>
        <p>{item.name}</p>
        <p>{item.category}</p>
        </div>
        
       ))}</div> :
       <div style={{"border":"2px solid black","height":"200px","width":"500px","backgroundColor":"lightyellow","padding":"10px","display":"flex"}}>
       {resultarray.map((item)=>(
            <div style={{"display":"flex","margin-left":"50px","padding":"10px"}}>
 
         <div style={{"border":"2px solid black","height":"150px","width":"100px","backgroundColor":"lightskyblue","alignItems":"center","padding":"10px"}}>
         <p>{item.id}</p>
         <p>{item.name}</p>
         <p>{item.category}</p>
         </div>
         </div>
        ))}
       </div>)}

     
       

       
      
       
        </>
        
      );
  }

  export default Product;