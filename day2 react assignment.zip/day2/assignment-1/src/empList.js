import { useState } from "react";

function empList() {

    const [empArray, setempArray] = useState([]);

    const [deptno, setDeptno] = useState("");
    const [ename, setEname] = useState("");
    const [sal, setSal] = useState("");
    const [job, setJob] = useState("");
    const [empno, setEmpno] = useState("");


    function getDeptsButton_click() {
        let tempArray = [
            { empno: 12, ename: "John", sal: "100000",job:"Database Administrator", deptno: 100 },
            { empno: 13, ename:"Peter", sal: "200000",job:"Cloud Engineer", deptno: 101 },
            { empno: 14, ename:  "Ben", sal: "300000",job:"Software Engineer", deptno: 102 },
            { empno: 15, ename: "Steve", sal: "400000",job:"Systems analyst", deptno: 103 },
          
        ];

        setempArray(tempArray);
    }

    function addDeptButton_click() {

        let tempArray = [...empArray];       
        
        let deptObj = {};
        deptObj.empno = empno;
        deptObj.ename = ename;
        deptObj.sal = sal;
        deptObj.job = job;
        deptObj.deptno = deptno;
        
        tempArray.push(deptObj);        

        setempArray(tempArray);


        setDeptno("");
        setEname("");
        setJob("");
        setSal("");
        setEmpno("");


    }

    function updateDept_click(dno) {

        let tempArray = [...empArray];    
        let index = tempArray.findIndex(item => item.empno == dno);

        tempArray[index].empno = empno;
        tempArray[index].ename = ename;
        tempArray[index].sal = sal;
        tempArray[index].job = job;
        tempArray[index].deptno = deptno;

        setempArray(tempArray);
        
        setDeptno("");
        setEname("");
        setJob("");
        setSal("");
        setEmpno("");

    }


    function deleteDept_click(dno) {

        let tempArray = [...empArray];    // cloning original array into temp array
        let index = tempArray.findIndex(item => item.empno == dno);
        tempArray.splice(index, 1);
        setempArray(tempArray);
    }


    let resultArray2 = empArray.map((item) => {
        return <tr>
            <td>   {item.empno}  </td>
            <td>   {item.ename}  </td>
            <td>   {item.sal}  </td>
            <td>   {item.job}  </td>
            <td>   {item.deptno}  </td>
            <td>
                <a href="javascript:void(0);" 
                   onClick={() => deleteDept_click(item.empno)}>Delete</a>
            </td>
            <td>
                <a href="javascript:void(0);" 
                   onClick={() => updateDept_click(item.empno)}>update</a>
            </td>
        </tr>
    });

    return (
        <>
            <h3>Working with State -- CRUD Operations on Array of Objects</h3>
            <hr />

            <input type="text" placeholder="Emp Number" value={empno} onChange={ (e) => setEmpno(e.target.value)} />
            <input type="text" placeholder="Emp Name" value={ename} onChange={ (e) => setEname(e.target.value)} />
            <input type="text" placeholder="Salary" value={sal} onChange={ (e) => setSal(e.target.value)} />
            <input type="text" placeholder="Job" value={job} onChange={ (e) => setJob(e.target.value)} />
            <input type="text" placeholder="Dept Number" value={deptno} onChange={ (e) => setDeptno(e.target.value)}/>

            <hr/>

            <input type="button" onClick={getDeptsButton_click} value="Get Emp's" />
            <input type="button" onClick={addDeptButton_click} value="Add Emp's" />
            
            <hr />

            <table border="2" width="400" cellspacing="0" cellpadding="5">
                <tr>
                    <th>Emp Number</th>
                    <th>Emp Name</th>
                    <th>Salary</th>
                    <th>Job</th>
                    <th>Dept Number</th>
                    <th></th>
                </tr>
                {resultArray2}
            </table>
        </>
    );
}

export default empList;