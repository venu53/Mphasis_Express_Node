import { useState } from "react";


    function Price() {
        const [product, setProduct] = useState( );
        const [quantity, setQuantity] = useState( );
        const [price, setPrice] = useState( );
        const [totalprice, setTotalPrice] = useState();
    
    
        function buttonClick() {
            if (!isNaN(price) && !isNaN(quantity) ) {
                
                setTotalPrice(price*quantity);
                
            }
            else {
                setTotalPrice("Invalid price or quantity");
               
            }
    
        }
    
        return (
            <>
                <h3>Event Handling in React JS</h3>
                <hr />
                <fieldset>
                    <legend>Product Calc</legend>
                    product name :  
                <input type="text" onChange={ (e) => setProduct(e.target.value)} />
                <br /> <br />

                price: 
                <input type="number" onChange={ (e) => setPrice(e.target.value) } />
                <br /> <br />
                quantity: 
                <input type="number" onChange={ (e) => setQuantity(e.target.value) } />
                <br /> <br />
                    
                    <input type="button" onClick={buttonClick} value="Get Total" />
                    <p>Totalprice={totalprice}</p>
                </fieldset>
    
            </>
        );
}




export default Price;