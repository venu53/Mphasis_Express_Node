import React from 'react';
import DocList from './DeptList';
import Login from './login';
import Price from './price';
import DeptList from './crud';
import EmpList from './empList';

function App() {
  return (
    <>
      <h3 align="center">Welcome to React Applications</h3>
      <hr />
      <DeptList/> 
      <Login/>
      <EmpList/>
      <Price/>
      

       <DocList />
    </>
  );
}

export default App;