function DocList() {

    let docArray = [
        { doctorId: 1, doctorName: "Dr. Ajaya Nand", designation: "Neurosurgery", experience: 8, contactNumber: 123456789 },
        { doctorId: 2, doctorName: "Dr. Suresh Joshi", designation: "Physician", experience: 9, contactNumber: 23456789 },
        { doctorId: 3, doctorName: "Dr. Abhijit Dey", designation: "Dermatologist", experience: 11, contactNumber: 34567899 },
        { doctorId: 4, doctorName: "Dr. Aroop Mukherjee", designation: "Endocrinologist", experience: 10, contactNumber: 98765321 },
    ];

    let studentObj = { sid: 1, sname: "john", course: "react", age: "22" };



    let resultArray = docArray.map((item) => {
        return <tr>
            <td>   {item.doctorId}  </td>
            <td>   {item.doctorName}  </td>
            <td>   {item.designation}  </td>
            <td>   {item.experience}  </td>
            <td>   {item.contactNumber}  </td>
        </tr>
    });



    return (
        <>
            <h3>Array of Doctors </h3>
            <table border="2" width="400" cellspacing="0" cellpadding="5">
                <tr>
                    <th>DocterID</th>
                    <th>DocterName</th>
                    <th>Designation</th>
                    <th>Experience</th>
                    <th>contact Numaber</th>
                </tr>
                {resultArray}
            </table>

            <hr />

          
                <h3>Single Object</h3>

                <table border=" 2px solid black">
                    <tr> <td> sid</td> <td> {studentObj.sid} </td></tr>
                    <tr> <td> sname</td> <td> {studentObj.sname}  </td></tr>
                    <tr> <td> course</td> <td> {studentObj.course}</td></tr>
                    <tr> <td>  age </td> <td>{studentObj.age} </td></tr>
                </table>
             
            <hr />
        </>
    );

}

export default DocList;