const express = require("express");
const router = express.Router();


router.get("/smartphone", function (req, res) {       
    let dataObj = {};    
    dataObj.prodArray = [
        { pid: 1, pname: "samsung", price: "60000" ,quantity:2,categroy:"smart phone"},
        { pid: 2, pname: "apple", price: "60000" ,quantity:3,categroy:"smart phone" },
        { pid: 3, pname: "vivo", price: "30000" ,quantity:5,categroy:"smart phone"},
        { pid: 4, pname: "oneplus", price: "40000" ,quantity:7,categroy:"smart phone"},
       
    ];

    res.render("showallproducts", dataObj);
});

router.get("/GetProductById", function (req, res) {

    var prodArray = [
     { pid: 1, pname: "samsung", price: "60000" ,quantity:2,categroy:"smart phone"},
     { pid: 2, pname: "apple", price: "60000" ,quantity:3,categroy:"smart phone" },
     { pid: 3, pname: "vivo", price: "30000" ,quantity:5,categroy:"smart phone"},
     { pid: 4, pname: "oneplus", price: "40000" ,quantity:7,categroy:"smart phone"},
      
     ];
 
     // let dno = req.params.id;
     let dno = req.query.dno;
    
     let dataObj = {};    
     dataObj.prodObj = prodArray.find( item => item.pid == dno );
     
 
     res.render("productdetails", dataObj);
 });





module.exports = router;