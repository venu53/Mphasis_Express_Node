const express = require("express");
const router = express.Router();

router.get("/AllProducts", function (req, res) {

    let dataObj = {};    
    dataObj.prodArray = [
        { pid: 1, pname: "samsung", price: "60000" ,quantity:2,categroy:"smart phone"},
        { pid: 2, pname: "apple", price: "60000" ,quantity:3,categroy:"smart phone" },
        { pid: 3, pname: "vivo", price: "30000" ,quantity:5,categroy:"smart phone"},
        { pid: 4, pname: "oneplus", price: "40000" ,quantity:7,categroy:"smart phone"},
        { pid: 5, pname: "tv", price: "25000" ,quantity:2,categroy:"Home appliance"},
        { pid: 6, pname: "refrigerator", price: "35000" ,quantity:3,categroy:"Home appliance" },
        { pid: 7, pname: "washing machines", price: "15000" ,quantity:5,categroy:"Home appliance"},
        { pid: 8, pname: " microwave oven", price: "5000" ,quantity:7,categroy:"Home appliance"},
    ];

    res.render("showallproducts", dataObj);
});

// router.get("/GetDeptById/:id", function (req, res) {
router.get("/GetProductById", function (req, res) {

   var prodArray = [
    { pid: 1, pname: "samsung", price: "60000" ,quantity:2,categroy:"smart phone"},
    { pid: 2, pname: "apple", price: "60000" ,quantity:3,categroy:"smart phone" },
    { pid: 3, pname: "vivo", price: "30000" ,quantity:5,categroy:"smart phone"},
    { pid: 4, pname: "oneplus", price: "40000" ,quantity:7,categroy:"smart phone"},
    { pid: 5, pname: "tv", price: "25000" ,quantity:2,categroy:"Home appliance"},
    { pid: 6, pname: "refrigerator", price: "35000" ,quantity:3,categroy:"Home appliance" },
    { pid: 7, pname: "washing machines", price: "15000" ,quantity:5,categroy:"Home appliance"},
    { pid: 8, pname: " microwave oven", price: "5000" ,quantity:7,categroy:"Home appliance"},
    ];

    // let dno = req.params.id;
    let dno = req.query.dno;
    console.log("dno1=",dno);
    let dataObj = {};    
    dataObj.prodObj = prodArray.find( item => item.pid == dno );
    console.log("dno2=",dno);

    res.render("productdetails", dataObj);
});

module.exports = router;