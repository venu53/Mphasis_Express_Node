const express = require("express");
const bodyParser = require("body-parser");  
const deptsRouter = require('./depts-routes');
const smRouter = require('./smartphone');
const haRouter = require('./homeappliance');

// Creates an express application
var app = express();   

app.use(bodyParser.urlencoded({extended : false})); 
// app.use(userRouter);

app.use("/prods", deptsRouter);
app.use("/prods", smRouter);
app.use("/prods", haRouter);
 
// Confgiure the middleware
app.set("view engine", "ejs");

app.get("/", function (req, res) {   
    res.render("home", {});
});


var server = app.listen(3006, function () { });
console.log("Express Server Application is started. Browser at the URL: http://localhost:3006/");