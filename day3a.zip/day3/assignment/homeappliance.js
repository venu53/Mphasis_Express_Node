const express = require("express");
const router = express.Router();

router.get("/homeappliance", function (req, res) {       
    let dataObj = {};    
    dataObj.prodArray = [
        
        { pid: 5, pname: "tv", price: "25000" ,quantity:2,categroy:"Home appliance"},
        { pid: 6, pname: "refrigerator", price: "35000" ,quantity:3,categroy:"Home appliance" },
        { pid: 7, pname: "washing machines", price: "15000" ,quantity:5,categroy:"Home appliance"},
        { pid: 8, pname: " microwave oven", price: "5000" ,quantity:7,categroy:"Home appliance"},
    ];

    res.render("showallproducts", dataObj);

    
});

router.get("/GetProductById", function (req, res) {

    var prodArray = [
      
     { pid: 5, pname: "tv", price: "25000" ,quantity:2,categroy:"Home appliance"},
     { pid: 6, pname: "refrigerator", price: "35000" ,quantity:3,categroy:"Home appliance" },
     { pid: 7, pname: "washing machines", price: "15000" ,quantity:5,categroy:"Home appliance"},
     { pid: 8, pname: " microwave oven", price: "5000" ,quantity:7,categroy:"Home appliance"},
     ];
 
     // let dno = req.params.id;
     let dno = req.query.dno;
   
     let dataObj = {};    
     dataObj.prodObj = prodArray.find( item => item.pid == dno );
    
 
     res.render("productdetails", dataObj);
 });






module.exports = router;