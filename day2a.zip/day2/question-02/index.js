var express = require("express");

var app = express();
 
app.use(express.static('public'));  

// app.set("view engine", "ejs");

app.set("view engine", "hbs");

app.get("/", function (req, res) {
    let dataObj = {};
    dataObj.Id  = 1;
    dataObj.email  = "george.bluth@reqres.in";
    dataObj.first_name  = "George";
    dataObj.last_name= "Bluth";
    
     

    // assingment2

    dataObj.data2Array=[ {"Name":"Alfreds Futterkiste","City":"Berlin","Country":"Germany"}, 
				 {"Name":"Ana Trujillo Emparedados y helados","City":"México D.F.","Country":"Mexico"}, 
				 {"Name":"Antonio Moreno Taquería","City":"México D.F.","Country":"Mexico"}, 
				 {"Name":"Around the Horn","City":"London","Country":"UK"}, 
				 {"Name":"B's Beverages","City":"London","Country":"UK"}, 
				 {"Name":"Berglunds snabbköp","City":"Luleå","Country":"Sweden"}, 
				 {"Name":"Blauer See Delikatessen","City":"Mannheim","Country":"Germany"}]
    res.render("home", dataObj);  

	
});

app.get("/login", function (req, res) {
    res.sendFile(__dirname + "/views/login.html");    
	
});


var server = app.listen(3001, function () { });

console.log("welcome to express JS class url:http:localhost:3001");