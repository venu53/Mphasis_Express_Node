var express = require("express");
var bodyParser = require("body-parser");   

 
var app = express();   

 
app.use(bodyParser.urlencoded({extended : false}));

app.set("view engine", "ejs");

app.get("/", function (req, res) {   
    res.render("home", {});
});

app.get("/Login", function (req, res) {       
    res.render("login", { errorMessage : "" });
});

app.post("/Login", function (req, res) {   

    // console.log("hello u r in post");
    
    let up= req.body.t2;
  let q = req.body.t3;
  

    if(!isNaN(up) && !isNaN(q) )
    {       
    //     console.log("value of up is ",up);
    //   console.log("value of q is ",q);
        let total=up*q;
        // console.log("value of up q is ",total);
        res.render("login", { errorMessage : total });
       
    }
    else
    {   res.render("login", { errorMessage : "Invalid price and quantity"  });
    }   
});

var server = app.listen(3001, function () { });

console.log("welcome to express JS class url:http:localhost:3001");