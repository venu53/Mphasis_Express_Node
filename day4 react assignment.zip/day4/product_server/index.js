const express = require('express');
const bodyParser = require("body-parser");
const cors = require("cors");  
const deptRouter = require('./product-routes');

var app=express();

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.use(cors());
app.use("/", deptRouter);

app.get("/", function(req,res)
{
    res.send("Welcomes you ");
});


var server=app.listen(3007,function() {});
console.log("Server Started. URL:http://localhost:3007");