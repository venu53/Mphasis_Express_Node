 
var mongoose = require('mongoose');

 
mongoose.connect('mongodb://localhost:27017/mphasis');
 
var Schema = mongoose.Schema;

 
var DeptModelSchema = new Schema(
    {   pid: Number, 
        pname: String, 
        price : String, 	
        quantity  : Number,  
       categroy : String  }, 
    { versionKey: false  } );

 
var ProductModel = mongoose.model('products', DeptModelSchema );

 
module.exports = ProductModel;

