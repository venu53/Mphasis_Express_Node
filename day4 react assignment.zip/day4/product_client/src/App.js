import React from 'react'; 
 
import AjaxDemo from './AjaxDemo';

function App() {   
  return (
    <> 
      <AjaxDemo />
    </>
  );
}

export default App;
