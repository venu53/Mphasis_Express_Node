import axios from 'axios';
import { useState } from 'react';

function AjaxDemo() {   

   const [productArray, setProductArray] = useState([]);
   const [pid, setPid] = useState("");
   const [pname, setPname] = useState("");
   const [price, setPrice] = useState("");
   const [quantity, setQuantity] = useState("");
   const [categroy, setCategroy] = useState("");



  function getDataButton_click() {

      let url = "http://localhost:3007/Depts/";
      axios.get(url).then( (resData) => 
      {       
        console.log(resData.data);
        setProductArray(resData.data);
      });
  }

  function addDeptButton_click() {
    
    let productobj = {};
    productobj.pid = pid;
    productobj.pname = pname;
    productobj.price = price;
    productobj.quantity = quantity;
    productobj.categroy = categroy;
      

    let url = "http://localhost:3007/Depts/";
    axios.post(url, productobj).then( (resData) => 
    {       
      alert(resData.data.status);
      getDataButton_click();
    });

   
    clearFields();
}

function clearFields()
{
    setPid("");
    setPname("");
    setPrice(""); 
    setQuantity(""); 
    setCategroy(""); 
}

function deleteDept_click(dno) {

  let flag = window.confirm("Are you sure want to delete?");    
  if(  flag == false   )
  {
      return;
  }

  let url = "http://localhost:3007/Depts/" + dno;
  axios.delete(url).then( (resData) => 
  {       
    alert(resData.data.status);
    getDataButton_click();
  });
}


  let resultArray = productArray.map(item => 
    {
      return <tr>
          <td>{item.pid}</td>
          <td>{item.pname}</td>
          <td>{item.price}</td>
          <td>{item.quantity}</td>
          <td>{item.categroy}</td>
          <td>
          <a href="javascript:void(0);" 
                   onClick={() => deleteDept_click(item.pid)}>
                    <img  src="images/delete.png"  width="20"  />
                </a> 
          </td>
      </tr>;
    });


  return (
    <div style={ {"border":"2px solid blue", "padding":"10px", "padding-bottom":"15px", "backgroundColor" : "lightyellow"}}>

      <h3>MERN Stack Implementation</h3>
      <hr/>

      <input type="text" placeholder="product ID" value={pid} onChange={ (e) => setPid(e.target.value)} />
            <input type="text" placeholder="product Name" value={pname} onChange={ (e) => setPname(e.target.value)} />
            <input type="text" placeholder="product Price" value={price} onChange={ (e) => setPrice(e.target.value)} />
            <input type="text" placeholder="product Quantity" value={quantity} onChange={ (e) => setQuantity(e.target.value)} />
            <input type="text" placeholder="product categroy" value={categroy} onChange={ (e) => setCategroy(e.target.value)} />
      <hr/>

      <input type="button" onClick={getDataButton_click} 
               value="Get Data" />
                           <input type="button" onClick={addDeptButton_click} value="Add Dept" />

      <hr/>

      <table  border="2" cellSpacing="0" width="500">
          <tr>
            <th>product Id</th>
            <th>product Name</th>
            <th>product Price</th>
            <th>product quantity</th>
            <th>product category</th>
            <th></th>
          </tr>
          {resultArray} 
      </table>         

    </div>
  );
}

export default AjaxDemo;
