var express = require("express");

var app = express();
 
app.use(express.static('public'));  

app.get("/", function (req, res) {
    res.sendFile(__dirname + "/views/home.html");    
	
});

app.get("/login", function (req, res) {
    res.sendFile(__dirname + "/views/login.html");    
	
});


var server = app.listen(3001, function () { });

console.log("welcome to express JS class url:http:localhost:3001");