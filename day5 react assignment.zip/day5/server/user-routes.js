const express = require("express");
const UserTable = require('./models/user-model');
const router = express.Router();

router.get("/User", async function (req, res) {


    let result = await UserTable.find({}, { "_id": 0 });
    try {
        console.log("[Read All] - No. of  items get from database : " + result.length);
        res.send(result);
    }
    catch (error) {

        res.status(500).send(error);
    }

});

router.post('/register', async function (req, res) {
    var userObj = new UserTable({
        uid: req.body.uid,
        pws: req.body.pws,
        rpws: req.body.rpws
    });
    console.log(userObj);

    // Logic to insert new dept in database
    let newObj = await userObj.save();

    var result = {};
    result.status = "Registraction is success";
    console.log("[Create] - Record inserted in Database");
    res.send(result);
});

router.post('/login', async function (req, res) {
    // const {uid,pws}=res.body;
    // var userObj = new UserTable({
    //     uid: req.body.uid,
    //    pws: req.body.pws
    // })
    let user = await UserTable.findOne({ uid: req.body.uid })

    if(user){
        if (user.pws === req.body.pws)
     {
        res.json("success")
    }
    else {
        res.json("invalid")

    }}
    else{
        res.json("new");
        console.log("new user");
    }

    console.log(user);
});

module.exports = router;