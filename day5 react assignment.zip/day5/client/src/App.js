 
import './App.css';

function App() {
  return (
    <div style={{ textAlign: "center" }} >
      <h3>Welcome to SPA using React JS</h3>
      <img src="/Images/Banner.jpg" width="90%" height="250" alt="Alternate text" />
    </div>
  );
}


export default App;
