import axios from 'axios';
import React, {useState} from 'react';
import { useLocation, useNavigate} from "react-router-dom";
import { Link } from "react-router-dom";

function Login() {   

    const [uid, setUserId]  = useState("");
    const [pws, setPassword]  = useState("");
    

    let navigate = useNavigate(); // for navigation using code
    let location = useLocation(); // for reading query string params

    function loginButton_click(e)
    {      
      e.preventDefault();

       const queryString = location.search; // returns the query string from the current url
      // let strReturnUrl  =  new URLSearchParams(search).get('key');
       let strReturnUrl  =  new URLSearchParams(queryString).get('returnUrl');

      
       if(strReturnUrl == null)
       {
        strReturnUrl = "/";
       }
       let url="http://localhost:3007/login/";

       axios.post(url,{uid,pws}).then((resdata)=>{

        if(resdata.data === "success")
        {
          console.log(resdata.data);
          alert("login succusfull");
           // In real-time apps, we will get the token from the server
          // JWT token is the popular token generation library          
          let token = "ASJDFJF87ADF8745LK4598SAD7FAJSDF45JSDLFKAS";
          sessionStorage.setItem('user-token', token);
           // navigate("/Depts");
           navigate(strReturnUrl);
        }

      else {
        alert("Invalid details");
      }

       })
      
        // if(uid == "admin" && pwd == "admin123")
        // {   
        //   // In real-time apps, we will get the token from the server
        //   // JWT token is the popular token generation library          
        //    let token = "ASJDFJF87ADF8745LK4598SAD7FAJSDF45JSDLFKAS";
        //    sessionStorage.setItem('user-token', token);
        //   // navigate("/Depts");
        //    navigate(strReturnUrl);
        // }
        // else
        // {
        //     setResult("Invalid User Id or Password");
        // }
    }


  return (
    <>   
     <div style={{"border":"2px solid black","height":"250px","width":"300px","marginLeft":"400px",marginTop:"100px",padding:"20px"}}>
                <h2 style={{textAlign:"center"}}>User login</h2>

                <label>User Id  : </label>
                <input type="text" value={uid} onChange={(event) => setUserId(event.target.value)} />
                <br/><br/>

                <label>Password  : </label>
                <input type="password"  value={pws}  onChange={(event) => setPassword(event.target.value)} />
                <br/><br/>

                <input type="button"  onClick={loginButton_click}  value="Login"  style={{marginTop:"20px",marginLeft:"20px"}}  />
                <Link to="/Register" style={{margin:"50px"}}>Register</Link>  
                </div>
    </>
  );

}

export default Login;
