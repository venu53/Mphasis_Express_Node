import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';
import reportWebVitals from './reportWebVitals';
 
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import Register from './Components/Register';
 

const routing = (
  <Router>
    <h3 style={{ textAlign: "center" }}>Routing Implementation using React JS Applications</h3>
    <hr />
    <div style={{ textAlign: "center" }}>
       
      <Link to="/Login">Login</Link> |
      <Link to="/Register">Register</Link> |
    </div>
    <hr />
    <Routes>
       
      <Route path="/register" element={<Register/>}></Route>
      <Route path="/login" element={<Login/>}></Route>
      <Route path="/" element={<App />} />

 
    </Routes>
  
  </Router>
);

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    {routing} 
  </React.StrictMode>
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
