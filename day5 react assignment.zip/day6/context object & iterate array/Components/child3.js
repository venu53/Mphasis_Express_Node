import axios from 'axios';
import { useContext } from 'react';
import { userDetailsContext } from '././parent';


function Child3(props) {     
    
  var  contextData  = useContext(userDetailsContext);

  let empArray =[
    { empno: 10, ename: "Accountent", loc: "Hye" , sal:12000 },
    { empno: 20, ename: "Sales_man",    loc: "Pune", sal:13000 },
    { empno: 30, ename: "Marketing_staff", loc: "Hye", sal:14000 },
    { empno: 40, ename: "Operations_staff", loc: "Chennai", sal:15000 },
];
 
  return (<div>
           <div style={{margin:"10px", border:"2px solid Red"}}>  
          <h3>This is Grand Child Component</h3>       
          <hr/>

          <div>
              User Name  :  {contextData.name} <br/>
              User Age  :  {contextData.age} <br/>
              User Email  :  {contextData.email} <br/>
          </div>
          </div>

          <h2>object itaration</h2>
          <table style={{"border":"2px solid black"}}>

            <thead>
              <tr>
                <th>EmpNo</th>
                <th>EmpDept</th>
                <th>EmpLoc</th>
                <th>EmpSalary</th>
              </tr>
            </thead>
            <tbody>
              {empArray.map((item,index) =>
              (<tr key={index}>
                {Object.values(item).map((value,index)=>
                (<td key={index}>{value}</td>))}
              </tr>))}
            </tbody>
          </table>



        </div>);
}

export default Child3;