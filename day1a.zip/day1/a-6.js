var express = require("express");

var app = express();

app.get("/", function (req, res) {


    var str = `<div style="height:150px;width:250px;">
     <table style="width:100%;border:2px solid black">
    <tr>
      <th>Employee id:</th>
      <td>01234</td>
    </tr>
    <tr>
      <th>Employee Name:</th>
      <td>abc</td>
    </tr>
    <tr>
      <th>Employee Job :</th>
      <td>ZYX</td>
    </tr>
    <tr>
    <th>Employee Deptno :</th>
    <td>8</td>
  </tr>
  <tr>
  <th>Employee EmailId:</th>
  <td>abc@gmail.com</td>
</tr>
  </table>
    
              </div>`;

    // var str = `<div style="color:white;height:150px;width:250px;background-color:black;border-radius:4px;
    // text-align:center;padding-top:10px">Employee data <br>
    //           Employee id:01234<br>
    //           Employee Name:abc<br>
    //           Employee Job : ZYX<br>
    //           Employee Deptno :  10<br>
    //           Employee EmailId:abc@gmail.com<br>
    //           </div>`;
    //   var str="Employee data <br>";
    //   str+="Employee id:01234<br>";
    //   str+="Employee Name:abc<br>";
    //   str+="Employee Job : ZYX<br>";
    //   str+="Employee Deptno :  10<br>";
    //   str+="Employee EmailId : abc@gmail.com<br>";			

    res.send(str);
});

var server = app.listen(3001, function () { });

console.log("welcome to express JS class url:http:localhost:3001");