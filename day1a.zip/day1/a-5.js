var express = require("express");

var app = express();
var idno="0123";
var name="abc";
var job="zxy";
var deptno="8";
var emailid="abc@gmail.com";

app.get("/", function (req, res) {


//     var str = `<div style="height:150px;width:250px;">
//      <table style="width:100%;border:2px solid black">
//     <tr>
//       <th>Employee id:</th>
//       <td>01234</td>
//     </tr>
//     <tr>
//       <th>Employee Name:</th>
//       <td>abc</td>
//     </tr>
//     <tr>
//       <th>Employee Job :</th>
//       <td>ZYX</td>
//     </tr>
//     <tr>
//     <th>Employee Deptno :</th>
//     <td>8</td>
//   </tr>
//   <tr>
//   <th>Employee EmailId:</th>
//   <td>abc@gmail.com</td>
// </tr>
//   </table>
    
//               </div>`;

    var str = `<div style="color:white;height:150px;width:250px;background-color:black;border-radius:4px;
    text-align:center;padding-top:10px">Employee data <br>
              Employee id:${idno}<br>
              Employee Name:${name}<br>
              Employee Job :${job}<br>
              Employee Deptno :  ${deptno}<br>
              Employee EmailId:${emailid}<br>
              </div>`;
    //   var str="Employee data <br>";
    //   str+="Employee id:01234<br>";
    //   str+="Employee Name:abc<br>";
    //   str+="Employee Job :${idno}<br>";
    //   str+="Employee Deptno :  10<br>";
    //   str+="Employee EmailId : abc@gmail.com<br>";			

    res.send(str);
});

var server = app.listen(3001, function () { });

console.log("welcome to express JS class url:http:localhost:3001");