var express =require("express");

var app=express();

app.get("/",function(req,res){
  var str="hello<br>";
  str+="Employee id:01234<br>";
  str+="Employee Name:abc<br>";
  str+="Employee Job : ZYX<br>";
  str+="Employee Deptno :  10<br>";
  str+="Employee EmailId : abc@gmail.com<br>";			
			 
    res.send(str);
});

var server=app.listen(3001,function(){});

console.log("welcome to express JS class url:http:localhost:3001");