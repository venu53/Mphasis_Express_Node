import BankApp from './Components/BankApp'; 

function App() 
{      
      return(
        <>
             <BankApp  />
        </>
        );
}

export default App;