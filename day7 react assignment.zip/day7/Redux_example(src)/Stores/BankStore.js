import { legacy_createStore as createStore } from 'redux';

// Step1:   Reducer Function
const bankReducer = (state, action) => 
{
    // Convert action type to upper case
    action.type = action.type.toUpperCase();    

    // alert(action.type);
    let  updatedState = {};

    switch (action.type) 
    {
        case "CREATE":
            updatedState.balance =  0;   
            break; 

        case "DEPOSIT":
            if((state.balance < 500) &&(parseFloat(action.amount)<500))
            {
            alert("Deposit minimum of $500")
            updatedState.balance =  state.balance + 0;
            }
            else
            updatedState.balance =  state.balance + parseFloat(action.amount);
          
            break;
            
        case "WITHDRAW":
            if(state.balance < parseFloat(action.amount))  
            {
                alert("Insufficient Fund");
                updatedState.balance =  state.balance;
            }
            
            else 
            {
                let min=state.balance;
                min=min-500;
                if(min < parseFloat(action.amount))
                {
                    alert("maintain minimum balance of $100");
                    updatedState.balance=state.balance;

                }
                else
                updatedState.balance =  state.balance - parseFloat(action.amount);
            
            }
            break;
        default:
           updatedState = state;
           break;
      }

      return updatedState;
};

// Step2:  Create Store
const bankStore = createStore(bankReducer);
export default bankStore;