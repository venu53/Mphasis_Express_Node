 
var mongoose = require('mongoose');

 
mongoose.connect('mongodb://localhost:27017/mphasis235');
 
var Schema = mongoose.Schema;

 
var DeptModelSchema = new Schema(
    {   name: String, 
        email : String, 	
        username  : String,  
       password  : String  }, 
    { versionKey: false  } );

 
var DeptModel = mongoose.model('students', DeptModelSchema );

 
module.exports = DeptModel;

