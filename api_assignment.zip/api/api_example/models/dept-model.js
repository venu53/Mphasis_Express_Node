//Import  Mongoose Module
var mongoose = require('mongoose');

// Connect to Mongodb  database(testDb is database name)
mongoose.connect('mongodb://localhost:27017/testDb');
// ,(err) => {
//     if(!err){
//         console.log('mongo is conneted')

//     }
//     else if(err){
//         console.log(err)
//     }


// Create  schema
var Schema = mongoose.Schema;

// Schema properties should be match mongodb collection properites
var DeptModelSchema = new Schema(
    {   deptno: Number, 
        dname : String, 	
        loc  : String   }, 
    { versionKey: false  } );

// Create Model Object	
// "depts"   --- collection name in mongodb
var DeptModel = mongoose.model('depts', DeptModelSchema );

// Exporting DeptModel 
module.exports = DeptModel;

