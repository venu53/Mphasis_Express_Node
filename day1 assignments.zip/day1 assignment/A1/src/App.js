import React from 'react';
import DocList from './DeptList';

function App() {
  return (
    <>
      <h3 align="center">Welcome to React Applications</h3>
      <hr />

       <DocList />
    </>
  );
}

export default App;