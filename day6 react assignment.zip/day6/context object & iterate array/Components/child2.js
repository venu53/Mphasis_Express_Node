import Child3 from '././child3';
 

function Child2() {


  return (<div style={{ margin: "10px", border: "2px solid Green" }}>
    <h3>This is Child Component</h3>
    <hr />
    <Child3 />
  </div>);
}

export default Child2;

