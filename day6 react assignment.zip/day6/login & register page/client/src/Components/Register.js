import React from "react";
import { Link } from "react-router-dom";
import { useState } from "react";
import axios from "axios";

function Register() {

    const [uid, setUserId] = useState("admin");
    const [pws, setPassword] = useState("admin123");
    const [rpws, setRepassword] = useState("admin123");
    // const [result, setResult] = useState("");


    function registerButton_click(){

        let userObj={};
        userObj.uid=uid;
        userObj.pws=pws;
        userObj.rpws=rpws;

    let url = "http://localhost:3007/register/";
    axios.post(url,userObj).then( (resData) => 
    {   
        console.log(userObj);    
      alert(resData.data.status);
      
    });

    }

    return (

        <>
       <div style={{"border":"2px solid black","height":"250px","width":"300px","marginLeft":"400px",marginTop:"100px",padding:"20px"}}>
        <h2>Register Here!</h2>
        <hr/>
        <label>User Id: </label>
        <input type="text" placeholder="userid" value={uid} onChange={(e)=> setUserId(e.target.value)}/>
        <br/><br/>
        <label>Password: </label>
        <input type="password" placeholder="password" value={pws} onChange={(e)=> setPassword(e.target.value)}/>
        <br/><br/>
        <label>RePassword: </label>
        <input type="password" placeholder="re-password" value={rpws} onChange={(e)=> setRepassword(e.target.value)}/>
        <br/><br/>
        <button onClick={registerButton_click}  >register</button>
        <Link to="/Login"  style={{margin:"100px"}}>login</Link>
       </div>
            
        </>
    )
}
export default Register;